# Licencia del kit de memes STUBX · Agente Talón

- **Versión:** 0.2 · **Fecha:** 2026-09-27 (v0.1 con los cambios B2-1 a B2-6 del dictamen legal de la fase 8)

> En pocas palabras: puedes usar y adaptar las plantillas y la mascota para hacer **memes y contenido de fans sin ánimo de lucro**, siempre que dejes el aviso, no hables de precio ni llames a comprar, y no te hagas pasar por STUBX.

## 1. Qué cubre

Las imágenes de las carpetas `plantillas/`, `ejemplos/`, `piezas/` y `mascota/` (en adelante, «el kit»), incluido el dibujo del personaje **Agente Talón**. Los nombres «STUBX» y «Agente Talón» y el lema no se licencian: puedes mencionarlos para referirte al proyecto o dentro de un meme hecho con el kit, nada más (ver punto 4).

**No cubre:**
- Las **fuentes** de `fuentes/`: tienen su propia licencia, la **SIL Open Font License 1.1** (ver `OFL-Silkscreen.txt` y `OFL-Inter.txt`).
- El **código** del repositorio `github.com/stubxai/stubx-agent`: tiene su propia licencia (MIT).

**Origen y derechos.** El dibujo del Agente Talón se generó con una herramienta de inteligencia artificial para el proyecto STUBX, a partir de una descripción de texto y sin partir de imágenes o personajes de terceros. Puede que parte del kit no esté protegida por derechos de autor. Esta licencia solo concede los derechos que el titular tenga sobre el kit; si alguna parte no es suya, no se concede nada sobre ella.

## 2. Qué puedes hacer

Si cumples el punto 3, puedes, gratis y sin pedir permiso (es un permiso no exclusivo que se puede retirar):
1. Descargar el kit.
2. Hacer memes, viñetas, stickers y otro contenido de fans con él, y adaptarlo (añadir texto, recortar el fondo, combinar plantillas).
3. Publicarlo en redes sociales y webs **personales**, sin cobrar por ello.

## 3. Condiciones

1. **Sin ánimo de lucro:** no puedes vender el kit ni lo que hagas con él, ni usarlo en anuncios o promociones de pago, ni en productos (camisetas, NFT, etc.) sin permiso por escrito de STUBX (desde stubxai.hq@gmail.com o en una respuesta pública de @stubxai).
2. **Aviso visible:** mantén el pie «Memecoin experimental · puedes perderlo todo · no es consejo de inversión» o uno equivalente, legible.
3. **Nada financiero:** sin precios, subidas, rentabilidades, objetivos, gráficos, llamadas a comprar o vender, ni consejos de inversión.
4. **Sin direcciones de contrato:** no pongas CA ni direcciones de wallet en tus piezas.
5. **Sin suplantación:** no uses el kit para parecer una cuenta, web o canal oficial de STUBX. Lo único oficial es X **@stubxai**, la web oficial y **stubxai.hq@gmail.com**.
6. **Sin sorteos ni airdrops:** no lo uses para concursos con premio, airdrops, «whitelists», regalos ni para pedir dinero, datos personales, firmas de wallet o frases semilla.
7. **Sin ataques ni contenido ilegal:** nada de odio, acoso, contenido sexual, ni ataques por nombre a personas o proyectos reales.
8. **Respeta al personaje:** cara rosa, gema verde, sin deformar.

## 4. Lo que esta licencia no hace

- No te hace socio, embajador ni representante de STUBX, ni te da derecho a nada (tokens, pagos, reparto, acceso).
- No es una licencia de marca: no puedes registrar «STUBX», «Agente Talón» ni el lema, ni usarlos como nombre de otro proyecto o token, ni usar el avatar o el kit como logo o imagen de otro token, NFT, proyecto o perfil.
- STUBX no revisa ni respalda lo que publiques. Tu contenido es tuyo y es responsabilidad tuya.
- El kit se ofrece tal cual, sin garantías de ningún tipo. En la medida en que la ley lo permita, STUBX no responde de lo que otros hagan con él.
- Que @stubxai comparta un meme, con permiso de su autor, no significa que STUBX respalde a esa persona ni lo que diga fuera de ese meme.

## 5. Si se incumple

Si alguien incumple estas condiciones, el permiso para esa persona termina y @stubxai puede pedir que retire el contenido y denunciarlo en la plataforma.

## 6. Contacto

Solo por X **@stubxai** o por email **stubxai.hq@gmail.com**. Nunca pedimos dinero, fondos, claves privadas ni frases semilla.

Estas condiciones pueden cambiar. Cada versión lleva número y fecha. La vigente es la del kit publicado en la web oficial.
