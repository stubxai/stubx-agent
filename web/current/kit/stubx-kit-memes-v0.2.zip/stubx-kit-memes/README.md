# Kit de memes · Agente Talón (STUBX)

- **Versión:** 0.2 · **Fecha:** 2026-09-27
- **Canal oficial único:** X **@stubxai** · web: <https://superb-horse-9036f5.netlify.app/> · email: stubxai.hq@gmail.com

> **Memecoin experimental · puedes perderlo todo · no es consejo de inversión.**
> Este kit es para hacer humor sobre pruebas y agentes de IA. No es una llamada a comprar y no da derecho a nada.

---

## 1. Qué hay dentro

| Carpeta | Archivo | Para qué |
|---|---|---|
| `plantillas/` | `T01-pide-el-talon-vacia-1200x675.png` | Dos viñetas: un robot genérico dice algo (bocadillo vacío) y Agente Talón responde «¿Talón?». |
| | `T02-talon-opina-vacia-1080x1080.png` | Bocadillo grande vacío + Agente Talón. Para cualquier frase corta. |
| | `T05-escalera-de-pruebas-vacia-1080x1080.png` | Escalera de 4 niveles de prueba (de «nada» a «prueba pública»). La gema brilla más cuanta más prueba hay. |
| | `T06-ticket-ppm-vacio-1200x675.png` | Ticket PPM con las 4 casillas (wallet, logs, límites, kill-switch) sin marcar. Para agentes **imaginarios**. |
| | `T07-reaccion-vacia-1080x1080.png` | Imagen de reacción: banda de texto arriba y abajo. |
| | `T08-glosario-talon-vacia-1200x675.png` | Ficha «Glosario Talón»: palabra + definición en 2 líneas + «Cómo pedir el talón». |
| `ejemplos/` | `T01…T08-*-ejemplo*.png`, `M3-…`, `M8-…` | Cada plantilla rellenada con un ejemplo, y dos memes del equipo como referencia de estilo. |
| `piezas/` | `sello-ppm-incomplete-transparente.png` | Sello «PPM INCOMPLETE» con fondo transparente, para poner encima del ticket T06. |
| | `paleta-stubx-1200x675.png` | Los 11 colores oficiales con su código. |
| | `cabecera-stubx-1500x500-con-aviso.png` | Cabecera oficial v2.1 con aviso. **Solo** para artículos o menciones; no para la cabecera de tu perfil. |
| `mascota/` | `agente-talon-avatar-1080.jpg`, `agente-talon-avatar-512.png` | Avatar oficial de Agente Talón (el mismo de @stubxai), en cuadrado. |
| | `agente-talon-icono-cara-512.png` | Icono con la cara (el de la web). |
| `fuentes/` | `Silkscreen-*.ttf`, `Inter-*.ttf`, `OFL-*.txt` | Las fuentes de la marca. Licencia SIL Open Font License 1.1 (gratis, con su texto de licencia). |
| `LICENCIA.md` | — | Qué puedes y qué no puedes hacer con el kit. **Léela.** |

Todas las plantillas llevan abajo el pie **«@stubxai · Memecoin experimental · puedes perderlo todo · no es consejo de inversión»**. **No lo quites ni lo tapes.**

## 2. Cómo hacer un meme en 3 minutos (herramientas gratis)

1. Abre la plantilla en un editor gratis: **Photopea** (en el navegador), **GIMP**, **Krita**, **Canva** (plan gratis) o **Piskel** (pixel art).
2. Instala las fuentes de `fuentes/` (doble clic → Instalar) o súbelas al editor.
3. Escribe tu texto:
   - Títulos y bocadillos: **Silkscreen Bold**, en MAYÚSCULAS, color tinta `#120a0e` sobre fondo claro.
   - Frases largas: **Inter**.
   - Máximo 2–3 líneas por bocadillo. Si no cabe en un talón, no se lanza.
4. Exporta en PNG a 1080×1080 (cuadrado) o 1200×675 (horizontal).
5. Revisa la lista de la sección 3 antes de publicar.

## 3. Reglas (resumen de `LICENCIA.md`)

**✅ Sí**
- Humor sobre **pruebas, transparencia y agentes de IA**: frases genéricas, agentes imaginarios, excusas típicas.
- Consejos antiestafa: leer el handle letra a letra, comparar la dirección entera, no firmar nada que no entiendas.
- Usar a Agente Talón tal cual: cara rosa, gema verde, sin deformar.
- Dejar el pie con el aviso.

**❌ No**
- Nada de **precio, subidas, rentabilidad, «moon», «100x», «pump», «gem»**, gráficos, flechas verdes, cohetes o lunas.
- Nada de **«compra», «entra ya», «última oportunidad»** ni ninguna llamada a comprar o vender.
- **No pongas direcciones de contrato (CA)** en tus memes. La única CA oficial está en el post fijado de @stubxai y en la web oficial. Una CA en un meme se puede falsificar.
- No te hagas pasar por STUBX: no uses el avatar o la cabecera como foto o cabecera de tu perfil, ni digas que tu cuenta es oficial. Lo único oficial es **@stubxai**.
- No lo uses para sorteos, airdrops, «whitelists», regalos, promociones de pago ni para pedir dinero o datos.
- No ataques a personas ni proyectos reales por su nombre. Talón critica ideas y frases, no a gente.
- Nada ofensivo, de odio o ilegal.
- No uses el sello «PPM INCOMPLETE» sobre un proyecto real con nombre: solo sobre ideas o agentes inventados.

## 4. Cómo compartirlo

- Publícalo desde **tu** cuenta. Si quieres, menciona a **@stubxai**.
- Los domingos, @stubxai puede destacar algún meme de la comunidad en «Talón de la semana», **siempre pidiendo permiso antes, en una respuesta pública bajo tu meme (nunca por mensaje privado), y con crédito**.
- **Sin premios, sin concursos con dinero o tokens y sin pagos.** Lo hacemos por el meme.
- Nadie de STUBX te escribirá por mensaje privado para pedirte nada por tu meme. Si pasa, es una estafa.

## 5. Datos de marca

- Mascota: **Agente Talón** (en inglés, «Agent Stub»). Ticket rosa pixel con borde perforado, ojos cuadrados, boca recta y **gema verde** en el pecho. Seco, escéptico, con humor. Pide pruebas: wallet, logs, límites y kill-switch.
- Lema: **No stub, no story.** / **Sin talón, no hay historia.**
- La gema verde significa «el prototipo está en pie». **No** significa «aprobado para invertir».
- Colores: carbón `#0a090d` · panel `#17131b` · línea `#34232d` · rosa cara `#fc9faa` · rosa cuerpo `#fe8596` · rosa borde `#f17e8b` · rosa profundo `#f54d66` · verde gema `#26c635` · texto claro `#fff3f5` · tinta `#120a0e` · aviso `#ff5a6e`.
- Margen alrededor del avatar: al menos un 10 % de su tamaño. Tamaño mínimo del avatar completo: 32×32 px.

*Memecoin experimental · puedes perderlo todo · no es consejo de inversión. Canal oficial: X @stubxai.*
